"""
Theme configuration for the Code to Diagram Generator
Classic Royal Blue Theme
"""

# Color Palette - Classic Royal Blue Theme
COLORS = {
    # Primary colors - Classic Royal Blue
    "primary": "#4169E1",  # Royal Blue
    "primary_dark": "#1E40AF",  # Dark Royal Blue
    "primary_light": "#6495ED",  # Light Royal Blue
    "secondary": "#6B8E23",  # Olive Drab as complementary
    "accent": "#9370DB",  # Medium Purple as accent
    # Neutral colors
    "bg_primary": "#FFFFFF",
    "bg_secondary": "#F8FAFF",
    "bg_card": "#FFFFFF",
    "bg_sidebar": "#F0F4FF",
    # Text colors
    "text_primary": "#1E293B",
    "text_secondary": "#374151",
    "text_light": "#6B7280",
    "text_white": "#FFFFFF",
    # Status colors
    "success": "#10B981",
    "warning": "#F59E0B",
    "error": "#EF4444",
    "info": "#3B82F6",
    # Border colors
    "border_light": "#E5E7EB",
    "border_medium": "#D1D5DB",
    "border_dark": "#9CA3AF",
    # Gradients - Classic Royal Blue
    "gradient_primary": "linear-gradient(135deg, #4169E1 0%, #1E40AF 100%)",
    "gradient_secondary": "linear-gradient(135deg, #6495ED 0%, #4169E1 100%)",
    "gradient_header": "linear-gradient(135deg, #1E40AF 0%, #4169E1 100%)",
    "gradient_button": "linear-gradient(135deg, #4169E1 0%, #1E40AF 100%)",
    "gradient_button_hover": "linear-gradient(135deg, #1E40AF 0%, #1E3A8A 100%)",
    "gradient_card": "linear-gradient(135deg, #FFFFFF 0%, #F8FAFF 100%)",
    "gradient_sidebar": "linear-gradient(180deg, #F0F4FF 0%, #E8EDFF 100%)",
    # Shadows with blue undertones
    "shadow_light": "0 2px 8px rgba(30, 64, 175, 0.08)",
    "shadow_medium": "0 4px 12px rgba(30, 64, 175, 0.12)",
    "shadow_large": "0 8px 24px rgba(30, 64, 175, 0.15)",
}

# Layout Configuration
LAYOUT = {
    "max_width": "1200px",
    "sidebar_width": "280px",
    "card_border_radius": "12px",
    "button_border_radius": "8px",
    "input_border_radius": "6px",
    "shadow_light": COLORS["shadow_light"],
    "shadow_medium": COLORS["shadow_medium"],
    "shadow_large": COLORS["shadow_large"],
    "transition": "all 0.3s ease",
    "transition_fast": "all 0.15s ease",
}

# Typography
TYPOGRAPHY = {
    "font_family": "'Inter', 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif",
    "font_family_mono": "'Monaco', 'Menlo', 'Ubuntu Mono', monospace",
    "font_size_xs": "0.75rem",
    "font_size_sm": "0.875rem",
    "font_size_base": "1rem",
    "font_size_lg": "1.125rem",
    "font_size_xl": "1.25rem",
    "font_size_2xl": "1.5rem",
    "font_size_3xl": "1.875rem",
    "font_size_4xl": "2.25rem",
    "line_height": "1.6",
    "line_height_tight": "1.3",
}

# Component Styles
COMPONENTS = {
    "header": {
        "background": COLORS["gradient_header"],
        "text_color": COLORS["text_white"],
        "padding": "2rem 1rem",
        "border_radius": "0 0 24px 24px",
    },
    "card": {
        "background": COLORS["gradient_card"],
        "border": f"1px solid {COLORS['primary']}15",
        "box_shadow": LAYOUT["shadow_light"],
        "padding": "1.5rem",
        "margin_bottom": "1.5rem",
    },
    "button_primary": {
        "background": COLORS["gradient_button"],
        "color": COLORS["text_white"],
        "border": "none",
        "box_shadow": LAYOUT["shadow_light"],
        "hover_background": COLORS["gradient_button_hover"],
        "hover_box_shadow": LAYOUT["shadow_medium"],
    },
    "button_secondary": {
        "background": "transparent",
        "color": COLORS["primary"],
        "border": f"1px solid {COLORS['primary']}",
        "hover_background": f"{COLORS['primary']}08",
        "hover_border": f"1px solid {COLORS['primary_dark']}",
    },
    "sidebar": {
        "background": COLORS["gradient_sidebar"],
        "border_right": f"1px solid {COLORS['primary']}15",
    },
    "input": {
        "background": COLORS["bg_secondary"],
        "border": f"1px solid {COLORS['border_light']}",
        "focus_border": f"1px solid {COLORS['primary']}",
        "focus_box_shadow": f"0 0 0 3px {COLORS['primary']}15",
    },
}


def get_theme_css():
    """Generate CSS variables from theme configuration"""
    css_vars = []

    # Color variables
    for color_name, color_value in COLORS.items():
        css_vars.append(f"--color-{color_name.replace('_', '-')}: {color_value};")

    # Layout variables
    for layout_name, layout_value in LAYOUT.items():
        css_vars.append(f"--layout-{layout_name.replace('_', '-')}: {layout_value};")

    # Typography variables
    for typo_name, typo_value in TYPOGRAPHY.items():
        css_vars.append(f"--typo-{typo_name.replace('_', '-')}: {typo_value};")

    return "\n".join(css_vars)


# Export theme for easy access
theme_config = {
    "colors": COLORS,
    "layout": LAYOUT,
    "typography": TYPOGRAPHY,
    "components": COMPONENTS,
}
