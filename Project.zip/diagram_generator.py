import graphviz
import os
import re
from typing import Dict, Any


def generate_diagram(parsed_data: Dict[str, Any]) -> tuple[str, str]:
    """Generate simple Graphviz diagram from parsed data"""

    # Create directed graph
    dot = graphviz.Digraph(comment="Code Structure")
    dot.attr(rankdir="TB")  # Top to bottom layout
    dot.attr("node", fontname="Arial", fontsize="10")
    dot.attr("edge", fontname="Arial", fontsize="9")

    try:
        # Add classes as rectangles
        for class_info in parsed_data.get("classes", []):
            class_name = class_info["name"]

            # Build class label safely - handle both Python and Java
            if parsed_data.get("language") == "java":
                class_label = build_java_class_label(class_info)
            else:
                class_label = build_python_class_label(class_info)

            # Clean the label to remove any problematic characters
            class_label = clean_label(class_label)

            dot.node(class_name, class_label, shape="record")

        # Add top-level functions (Python only)
        if parsed_data.get("language") == "python":
            functions = parsed_data.get("functions", [])
            for func_info in functions:
                if isinstance(func_info, dict):
                    func_name = func_info["name"]

                    # Check if this function is not a method of any class
                    is_method = any(
                        any(
                            isinstance(method, dict) and method.get("name") == func_name
                            for method in cls.get("methods", [])
                        )
                        for cls in parsed_data.get("classes", [])
                    )

                    if not is_method:
                        params = func_info.get("parameters", [])
                        param_str = ", ".join(str(p) for p in params) if params else ""
                        func_label = f"{func_name}({param_str})"
                        dot.node(func_name, clean_label(func_label), shape="ellipse")

                        # Add calls as edges
                        calls = func_info.get("calls", [])
                        for call in calls:
                            if (
                                call and call != func_name and isinstance(call, str)
                            ):  # Avoid self-references
                                dot.edge(func_name, clean_label(call))

        # Add inheritance relationships for Java
        if parsed_data.get("language") == "java":
            for class_info in parsed_data.get("classes", []):
                if class_info.get("extends"):
                    dot.edge(
                        class_info["name"],
                        class_info["extends"],
                        style="dashed",
                        color="blue",
                        label="extends",
                    )

        # Add method calls within classes
        for class_info in parsed_data.get("classes", []):
            class_name = class_info["name"]
            methods = class_info.get("methods", [])

            for method in methods:
                if isinstance(method, dict):
                    method_name = method.get("name", "")
                    calls = method.get("calls", [])

                    for call in calls:
                        if call and call != method_name and isinstance(call, str):
                            # Check if the call is to another method in the same class
                            if any(
                                m.get("name") == call
                                for m in methods
                                if isinstance(m, dict)
                            ):
                                dot.edge(
                                    f"{class_name}:{method_name}",
                                    f"{class_name}:{call}",
                                    style="dotted",
                                )
                            # Or if it's a call to another class
                            elif any(
                                cls["name"] == call
                                for cls in parsed_data.get("classes", [])
                            ):
                                dot.edge(
                                    f"{class_name}:{method_name}", call, style="dotted"
                                )

        # Ensure assets directory exists
        os.makedirs("assets/diagrams", exist_ok=True)

        # Render diagram
        base_name = os.path.splitext(parsed_data["filename"])[0]
        diagram_path = f"assets/diagrams/{base_name}"

        try:
            dot.render(diagram_path, format="png", cleanup=True)
            return dot.source, diagram_path + ".png"
        except Exception as e:
            print(f"Graphviz rendering error: {e}")
            # Try simple diagram as fallback
            return create_simple_diagram(parsed_data)

    except Exception as e:
        error_msg = f"Error in diagram generation: {str(e)}"
        print(error_msg)
        return create_error_diagram(error_msg)


def build_java_class_label(class_info: Dict[str, Any]) -> str:
    """Build label for Java classes"""
    class_name = class_info["name"]
    label_parts = [f"{class_name}\\n---"]

    # Add fields
    fields = class_info.get("fields", [])
    for field in fields[:5]:  # Limit fields to avoid huge labels
        if isinstance(field, dict):
            field_type = field.get("type", "")
            field_name = field.get("name", "")
            modifiers = field.get("modifiers", [])
            mod_str = " ".join(str(m) for m in modifiers) + " " if modifiers else ""
            label_parts.append(f"\\n{mod_str}{field_type} {field_name}")

    if fields:
        label_parts.append("\\n---")

    # Add methods
    methods = class_info.get("methods", [])
    for method in methods[:8]:  # Limit methods to avoid huge labels
        if isinstance(method, dict):
            method_name = method.get("name", "")
            return_type = method.get("return_type", "void")
            modifiers = method.get("modifiers", [])
            mod_str = " ".join(str(m) for m in modifiers) + " " if modifiers else ""
            label_parts.append(f"\\n+ {mod_str}{return_type} {method_name}()")

    if len(methods) > 8:
        label_parts.append(f"\\n+ ... ({len(methods) - 8} more methods)")

    return "".join(label_parts)


def build_python_class_label(class_info: Dict[str, Any]) -> str:
    """Build label for Python classes"""
    class_name = class_info["name"]
    label_parts = [f"{class_name}\\n---"]

    # Add attributes
    attributes = class_info.get("attributes", [])
    for attr in attributes[:3]:  # Limit attributes
        label_parts.append(f"\\n{attr}")

    if attributes:
        label_parts.append("\\n---")

    # Add methods
    methods = class_info.get("methods", [])
    for method in methods[:6]:  # Limit methods
        if isinstance(method, dict):
            method_name = method.get("name", "")
            params = method.get("parameters", [])
            param_str = ", ".join(str(p) for p in params) if params else ""
            label_parts.append(f"\\n+ {method_name}({param_str})")

    if len(methods) > 6:
        label_parts.append(f"\\n+ ... ({len(methods) - 6} more methods)")

    return "".join(label_parts)


def create_simple_diagram(parsed_data: Dict[str, Any]) -> tuple[str, str]:
    """Alternative simple diagram generator for complex files"""
    dot = graphviz.Digraph(comment="Simple Code Structure")
    dot.attr(rankdir="TB")
    dot.attr("node", shape="box", style="rounded", fontname="Arial")

    # Just show classes and basic info
    for class_info in parsed_data.get("classes", []):
        class_name = class_info["name"]
        method_count = len(class_info.get("methods", []))
        field_count = len(class_info.get("fields", []))
        attr_count = len(class_info.get("attributes", []))

        if parsed_data.get("language") == "java":
            label = f"{class_name}\\n{method_count} methods\\n{field_count} fields"
        else:
            label = f"{class_name}\\n{method_count} methods\\n{attr_count} attributes"

        dot.node(class_name, clean_label(label))

    # Add inheritance
    if parsed_data.get("language") == "java":
        for class_info in parsed_data.get("classes", []):
            if class_info.get("extends"):
                dot.edge(
                    class_info["name"],
                    class_info["extends"],
                    style="dashed",
                    label="extends",
                )

    # Add function calls for Python
    if parsed_data.get("language") == "python":
        functions = parsed_data.get("functions", [])
        for func_info in functions:
            if isinstance(func_info, dict):
                func_name = func_info["name"]
                is_method = any(
                    any(
                        isinstance(m, dict) and m.get("name") == func_name
                        for m in cls.get("methods", [])
                    )
                    for cls in parsed_data.get("classes", [])
                )
                if not is_method:
                    dot.node(func_name, f"function {func_name}", shape="ellipse")

    os.makedirs("assets/diagrams", exist_ok=True)
    base_name = os.path.splitext(parsed_data["filename"])[0]
    diagram_path = f"assets/diagrams/{base_name}_simple"

    try:
        dot.render(diagram_path, format="png", cleanup=True)
        return dot.source, diagram_path + ".png"
    except Exception as e:
        return create_error_diagram(f"Simple diagram failed: {str(e)}")


def create_error_diagram(error_msg: str) -> tuple[str, str]:
    """Create an error diagram"""
    error_dot = graphviz.Digraph(comment="Error Diagram")
    error_dot.attr(rankdir="TB")

    # Shorten error message for display
    short_error = error_msg[:100] + "..." if len(error_msg) > 100 else error_msg
    error_label = f"Diagram Generation Error\\n{short_error}"

    error_dot.node("error", error_label, shape="octagon", color="red")

    os.makedirs("assets/diagrams", exist_ok=True)
    error_path = "assets/diagrams/error"

    try:
        error_dot.render(error_path, format="png", cleanup=True)
        return error_dot.source, error_path + ".png"
    except Exception:
        return 'digraph { error [label="Rendering Failed"] }', ""


def clean_label(label: str) -> str:
    """Clean label to make it Graphviz-safe"""
    if not isinstance(label, str):
        label = str(label)

    # Remove or replace problematic characters
    label = re.sub(r"[{}|<>]", "", label)  # Remove Graphviz special chars
    label = re.sub(r"'", '"', label)  # Replace single quotes with double
    label = re.sub(r"\n+", "\\n", label)  # Ensure proper newlines
    label = re.sub(r'"', '\\"', label)  # Escape double quotes
    label = re.sub(r"\\", "\\\\", label)  # Escape backslashes

    return label


# Backward compatibility
def generate_diagram_safe(parsed_data: Dict[str, Any]) -> tuple[str, str]:
    """Safe wrapper for diagram generation"""
    try:
        return generate_diagram(parsed_data)
    except Exception as e:
        return create_error_diagram(str(e))
