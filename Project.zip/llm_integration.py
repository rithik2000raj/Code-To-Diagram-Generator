import os
import requests
import time
from dotenv import load_dotenv
from typing import Dict, Any

# Load environment variables
load_dotenv()


class LLMIntegration:
    """Simple LLM integration for code analysis"""

    def __init__(self):
        self.api_key = os.getenv("GROQ_API_KEY")
        self.model = "llama-3.3-70b-versatile"
        self.base_url = "https://api.groq.com/openai/v1/chat/completions"

    def get_diagram_explanation(
        self, code_structure: Dict[str, Any], graphviz_code: str
    ) -> str:
        """Get 3-4 line diagram explanation"""
        if not self.api_key:
            return "API key required. Please set GROQ_API_KEY in your .env file."

        language = code_structure.get("language", "unknown")
        classes = code_structure.get("classes", [])
        class_count = len(classes)
        method_count = sum(len(cls.get("methods", [])) for cls in classes)

        prompt = f"""
        Provide a concise 5-6 line explanation of this {language} code diagram.
        
        Context: {class_count} classes, {method_count} methods, {code_structure.get('structure_summary', {}).get('architecture_type', 'modular')} architecture.
        
        Focus on: main components, key relationships, and overall structure.
        Keep it exactly 5-6 lines maximum.
        """

        return self._make_api_call(prompt)

    def get_code_response(
        self, question: str, source_code: str, code_structure: Dict[str, Any]
    ) -> str:
        """Get response to code questions"""
        if not self.api_key:
            return "API key required. Please set GROQ_API_KEY in your .env file."

        language = code_structure.get("language", "unknown")

        prompt = f"""
        Answer this question about {language} code in 5-6 concise lines:
        
        Question: {question}
        
        Code preview: {source_code[:500]}
        
        Structure: {len(code_structure.get('classes', []))} classes, {code_structure.get('structure_summary', {}).get('architecture_type', 'Unknown')} pattern.
        
        Provide a focused 5-6 line answer.
        """

        return self._make_api_call(prompt)

    def _make_api_call(self, prompt: str) -> str:
        """Make simple API call"""
        try:
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            }

            payload = {
                "model": self.model,
                "messages": [
                    {
                        "role": "system",
                        "content": "You are a code analysis expert. Always respond with exactly 3-4 concise lines. Be specific and technical.",
                    },
                    {"role": "user", "content": prompt},
                ],
                "temperature": 0.4,
                "max_tokens": 150,
                "top_p": 0.9,
            }

            response = requests.post(
                self.base_url, headers=headers, json=payload, timeout=30
            )

            if response.status_code == 429:
                return "Rate limit exceeded. Please wait a moment and try again."

            response.raise_for_status()
            data = response.json()

            response_text = data["choices"][0]["message"]["content"].strip()

            # Ensure response is 5-6 lines
            lines = [line.strip() for line in response_text.split("\n") if line.strip()]
            if len(lines) > 4:
                lines = lines[:6]
            return "\n".join(lines)

        except Exception:
            return "Unable to process request at this time."


# Global instance
llm = LLMIntegration()


# Public functions
def get_detailed_diagram_explanation(
    code_structure: Dict[str, Any], graphviz_code: str
) -> str:
    """Get 3-4 line diagram explanation"""
    return llm.get_diagram_explanation(code_structure, graphviz_code)


def get_code_analysis_response(
    question: str, source_code: str, code_structure: Dict[str, Any]
) -> str:
    """Get 3-4 line code analysis response"""
    return llm.get_code_response(question, source_code, code_structure)


def is_api_available() -> bool:
    """Check if API key is available"""
    return bool(llm.api_key)
