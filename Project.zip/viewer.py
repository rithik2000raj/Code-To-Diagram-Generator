import streamlit as st
import graphviz
import tempfile
import os
from theme_config import theme_config


def display_diagram_viewer(
    diagram_path: str, graphviz_code: str, editable: bool = False
):
    """
    Display diagram with editing capabilities

    Args:
        diagram_path: Path to the current diagram image
        graphviz_code: Current Graphviz source code
        editable: Whether to show editing controls

    Returns:
        tuple: (diagram_updated, new_graphviz_code)
    """
    COLORS = theme_config["colors"]
    LAYOUT = theme_config["layout"]

    # Display current diagram
    if diagram_path and os.path.exists(diagram_path):
        st.markdown(
            f'<div class="diagram-container" style="border: 1px solid {COLORS["primary"]}30; border-radius: {LAYOUT["card_border_radius"]};">',
            unsafe_allow_html=True,
        )
        st.image(diagram_path, use_column_width=True)
        st.markdown("</div>", unsafe_allow_html=True)
    else:
        st.error("No diagram available to display")
        return False, graphviz_code

    # Editing section
    if editable:
        return display_editable_diagram_section(graphviz_code)

    return False, graphviz_code


def display_editable_diagram_section(graphviz_code: str):
    """
    Display diagram editing controls

    Returns:
        tuple: (diagram_updated, new_graphviz_code)
    """
    COLORS = theme_config["colors"]

    st.markdown("---")
    st.subheader("Diagram Editor")

    # Graphviz code editor
    st.markdown("**Edit Graphviz Code:**")
    edited_code = st.text_area(
        "Graphviz Source",
        value=graphviz_code,
        height=300,
        key="graphviz_editor",
        label_visibility="collapsed",
    )

    # Action buttons in columns with consistent styling
    col1, col2, col3 = st.columns([1, 1, 1])

    diagram_updated = False
    new_graphviz_code = graphviz_code

    with col1:
        if st.button(
            "Apply Changes", use_container_width=True, key="apply_changes_btn"
        ):
            if edited_code != graphviz_code:
                st.session_state.apply_changes_clicked = True
                new_graphviz_code = edited_code
                diagram_updated = True

    with col2:
        if st.button(
            "↩Reset to Original", use_container_width=True, key="reset_original_btn"
        ):
            st.session_state.reset_original_clicked = True
            new_graphviz_code = st.session_state.graphviz_code
            diagram_updated = True

    with col3:
        if st.button("Export DOT", use_container_width=True, key="export_dot_btn"):
            export_graphviz_code(edited_code)

    # Display any errors
    if st.session_state.get("last_error"):
        st.error(st.session_state.last_error)

    return diagram_updated, new_graphviz_code


def export_graphviz_code(graphviz_code: str):
    """Export Graphviz code as downloadable file"""
    if not graphviz_code:
        st.warning("No Graphviz code to export")
        return

    base_name = "diagram"
    if st.session_state.processed_data:
        base_name = os.path.splitext(st.session_state.processed_data["filename"])[0]

    st.download_button(
        label="Download DOT File",
        data=graphviz_code,
        file_name=f"{base_name}.dot",
        mime="text/plain",
        use_container_width=True,
    )


def preview_graphviz_changes(graphviz_code: str):
    """
    Preview Graphviz changes without saving
    """
    if not graphviz_code:
        return None

    try:
        # Create temporary diagram for preview
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp_file:
            dot = graphviz.Source(graphviz_code)
            dot.render(tmp_file.name, format="png", cleanup=True)

            if os.path.exists(tmp_file.name + ".png"):
                return tmp_file.name + ".png"
            return None

    except Exception as e:
        st.error(f"Preview error: {str(e)}")
        return None


def create_simple_diagram_preview(processed_data: dict):
    """
    Create a simplified diagram preview for complex structures
    """
    from diagram_generator import create_simple_diagram

    try:
        dot_code, diagram_path = create_simple_diagram(processed_data)
        return diagram_path
    except Exception as e:
        st.error(f"Simple diagram preview failed: {e}")
        return None
