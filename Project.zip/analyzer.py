import json
from typing import Dict, List, Any, Set, Tuple
from collections import defaultdict, deque
import os


class CodeAnalyzer:
    """Robust code analysis for call graphs, relationships, and structure mapping"""

    def __init__(self):
        self.analysis_result = {}
        self.parsed_data = {}

    def analyze(self, parsed_data: Dict[str, Any]) -> Dict[str, Any]:
        """Main analysis entry point - safely orchestrates all analyses"""
        try:
            self.parsed_data = parsed_data
            self.analysis_result = parsed_data.copy()

            # Perform analyses in order of complexity
            self._safe_execute(self._analyze_basic_metrics, "basic metrics")
            self._safe_execute(self._analyze_imports, "imports")
            self._safe_execute(self._analyze_class_hierarchy, "class hierarchy")
            self._safe_execute(self._analyze_call_graph, "call graph")
            self._safe_execute(self._analyze_relationships, "relationships")
            self._safe_execute(self._analyze_complexity, "complexity")
            self._safe_execute(self._analyze_structure, "structure summary")

            return self.analysis_result

        except Exception as e:
            # Fallback: return at least the parsed data
            print(f"❌ Analysis failed, returning basic data: {e}")
            return parsed_data

    def _safe_execute(self, analysis_func, analysis_name: str):
        """Safely execute an analysis function with error handling"""
        try:
            analysis_func()
        except Exception as e:
            print(f"⚠️ {analysis_name} analysis skipped: {e}")
            # Don't re-raise, continue with other analyses

    def _analyze_basic_metrics(self):
        """Analyze basic code metrics"""
        classes = self._safe_get_list("classes")
        functions = self._safe_get_list("functions")
        imports = self._safe_get_list("imports")

        basic_metrics = {
            "total_classes": len(classes),
            "total_functions": len(functions),
            "total_imports": len(imports),
            "total_methods": sum(
                len(self._safe_get_list_from_dict(cls, "methods")) for cls in classes
            ),
            "language": self.parsed_data.get("language", "unknown"),
        }

        self.analysis_result["basic_metrics"] = basic_metrics

    def _analyze_imports(self):
        """Analyze import relationships"""
        imports = self._safe_get_list("imports")

        import_analysis = {
            "standard_library": [],
            "third_party": [],
            "internal": [],
            "total_count": len(imports),
        }

        standard_lib_modules = {
            "os",
            "sys",
            "json",
            "re",
            "ast",
            "typing",
            "collections",
            "datetime",
            "math",
            "random",
            "io",
            "tempfile",
            "pathlib",
            "logging",
        }

        for imp in imports:
            module_name = self._extract_module_name(imp)

            if any(module_name.startswith(lib) for lib in standard_lib_modules):
                import_analysis["standard_library"].append(module_name)
            elif "." in module_name and not module_name.startswith("."):
                import_analysis["third_party"].append(module_name)
            else:
                import_analysis["internal"].append(module_name)

        self.analysis_result["import_analysis"] = import_analysis

    def _analyze_class_hierarchy(self):
        """Analyze class inheritance and hierarchy"""
        classes = self._safe_get_list("classes")

        hierarchy = {
            "root_classes": [],
            "inheritance_chains": [],
            "interfaces": [],
            "abstract_classes": [],
        }

        # Find root classes (no parents)
        for cls in classes:
            if self._is_root_class(cls):
                hierarchy["root_classes"].append(cls.get("name", "unknown"))

        # Build inheritance chains
        for cls in classes:
            chain = self._build_inheritance_chain(cls, classes)
            if len(chain) > 1:
                hierarchy["inheritance_chains"].append(chain)

        self.analysis_result["class_hierarchy"] = hierarchy

    def _analyze_call_graph(self):
        """Build call graph analysis"""
        classes = self._safe_get_list("classes")
        functions = self._safe_get_list("functions")

        call_graph = {
            "nodes": {},
            "edges": [],
            "entry_points": [],
            "external_calls": [],
        }

        # Add classes and methods as nodes
        for cls in classes:
            class_name = cls.get("name", "unknown")
            class_node_id = f"class:{class_name}"

            call_graph["nodes"][class_node_id] = {
                "type": "class",
                "name": class_name,
                "methods": [],
            }

            # Add methods
            for method in self._safe_get_list_from_dict(cls, "methods"):
                if isinstance(method, dict):
                    method_name = method.get("name", "unknown")
                    method_node_id = f"method:{class_name}.{method_name}"

                    call_graph["nodes"][method_node_id] = {
                        "type": "method",
                        "class": class_name,
                        "name": method_name,
                        "calls": self._safe_get_list_from_dict(method, "calls"),
                    }

                    call_graph["nodes"][class_node_id]["methods"].append(method_node_id)

        # Add top-level functions
        for func in functions:
            if isinstance(func, dict):
                func_name = func.get("name", "unknown")
                func_node_id = f"function:{func_name}"

                call_graph["nodes"][func_node_id] = {
                    "type": "function",
                    "name": func_name,
                    "calls": self._safe_get_list_from_dict(func, "calls"),
                }

        # Build call edges
        self._build_call_edges(call_graph)

        self.analysis_result["call_graph"] = call_graph

    def _analyze_relationships(self):
        """Analyze relationships between components"""
        classes = self._safe_get_list("classes")

        relationships = {
            "inheritance": [],
            "composition": [],
            "association": [],
            "dependency": [],
        }

        # Inheritance relationships
        for cls in classes:
            if self.parsed_data.get("language") == "java":
                extends = cls.get("extends")
                if extends:
                    relationships["inheritance"].append(
                        {
                            "child": cls.get("name", "unknown"),
                            "parent": extends,
                            "type": "extends",
                        }
                    )
            else:  # Python
                bases = self._safe_get_list_from_dict(cls, "bases")
                for base in bases:
                    if base and base != "object":
                        relationships["inheritance"].append(
                            {
                                "child": cls.get("name", "unknown"),
                                "parent": base,
                                "type": "inherits",
                            }
                        )

        # Method call relationships
        for cls in classes:
            class_name = cls.get("name", "unknown")
            for method in self._safe_get_list_from_dict(cls, "methods"):
                if isinstance(method, dict):
                    for call in self._safe_get_list_from_dict(method, "calls"):
                        # Check if call targets another class
                        if any(call == other_cls.get("name") for other_cls in classes):
                            if call != class_name:
                                relationships["dependency"].append(
                                    {
                                        "source": class_name,
                                        "target": call,
                                        "via_method": method.get("name", "unknown"),
                                        "type": "method_call",
                                    }
                                )

        self.analysis_result["relationships"] = relationships

    def _analyze_complexity(self):
        """Analyze code complexity metrics"""
        classes = self._safe_get_list("classes")
        functions = self._safe_get_list("functions")

        complexity = {"class_metrics": {}, "method_metrics": {}, "overall_metrics": {}}

        total_methods = 0

        # Class-level complexity
        for cls in classes:
            class_name = cls.get("name", "unknown")
            methods = self._safe_get_list_from_dict(cls, "methods")
            total_methods += len(methods)

            complexity["class_metrics"][class_name] = {
                "method_count": len(methods),
                "attribute_count": len(
                    self._safe_get_list_from_dict(cls, "attributes")
                ),
                "field_count": len(self._safe_get_list_from_dict(cls, "fields")),
                "complexity_score": len(methods) * 2,
            }

        # Overall metrics
        complexity["overall_metrics"] = {
            "total_classes": len(classes),
            "total_methods": total_methods,
            "total_functions": len(functions),
            "average_methods_per_class": total_methods / len(classes) if classes else 0,
            "total_imports": len(self._safe_get_list("imports")),
        }

        self.analysis_result["complexity_analysis"] = complexity

    def _analyze_structure(self):
        """Generate structure summary"""
        classes = self._safe_get_list("classes")
        functions = self._safe_get_list("functions")

        summary = {
            "total_components": len(classes) + len(functions),
            "architecture_type": self._determine_architecture_type(),
            "main_components": [],
            "complexity_level": self._assess_complexity_level(),
        }

        # Identify main components (classes with most methods)
        if classes:
            sorted_classes = sorted(
                classes,
                key=lambda c: len(self._safe_get_list_from_dict(c, "methods")),
                reverse=True,
            )
            summary["main_components"] = [
                cls.get("name", "unknown") for cls in sorted_classes[:3]
            ]

        self.analysis_result["structure_summary"] = summary

    # ===== HELPER METHODS =====

    def _safe_get_list(self, key: str) -> List:
        """Safely get a list from parsed_data"""
        value = self.parsed_data.get(key)
        if value is None or isinstance(value, bool):
            return []
        return value if isinstance(value, list) else []

    def _safe_get_list_from_dict(self, data_dict: Dict, key: str) -> List:
        """Safely get a list from a dictionary"""
        if not isinstance(data_dict, dict):
            return []
        value = data_dict.get(key)
        if value is None or isinstance(value, bool):
            return []
        return value if isinstance(value, list) else []

    def _extract_module_name(self, imp) -> str:
        """Extract module name from import data"""
        if isinstance(imp, dict):
            return str(imp.get("name", ""))
        return str(imp)

    def _is_root_class(self, cls: Dict) -> bool:
        """Check if class is a root class (no parents)"""
        if self.parsed_data.get("language") == "java":
            return not cls.get("extends")
        else:  # Python
            bases = self._safe_get_list_from_dict(cls, "bases")
            return not bases or all(base == "object" for base in bases)

    def _build_inheritance_chain(self, cls: Dict, all_classes: List[Dict]) -> List[str]:
        """Build inheritance chain for a class"""
        chain = [cls.get("name", "unknown")]

        if self.parsed_data.get("language") == "java":
            parent_name = cls.get("extends")
            if parent_name:
                parent = next(
                    (c for c in all_classes if c.get("name") == parent_name), None
                )
                if parent:
                    chain.extend(self._build_inheritance_chain(parent, all_classes))
        else:  # Python
            bases = self._safe_get_list_from_dict(cls, "bases")
            for base in bases:
                if base and base != "object":
                    parent = next(
                        (c for c in all_classes if c.get("name") == base), None
                    )
                    if parent:
                        chain.extend(self._build_inheritance_chain(parent, all_classes))

        return chain

    def _build_call_edges(self, call_graph: Dict):
        """Build call edges in call graph"""
        for node_id, node_info in call_graph["nodes"].items():
            if node_info["type"] in ["method", "function"]:
                for call in self._safe_get_list_from_dict(node_info, "calls"):
                    target_node = self._find_call_target(call, call_graph["nodes"])
                    if target_node and target_node != node_id:
                        call_graph["edges"].append(
                            {"source": node_id, "target": target_node, "type": "calls"}
                        )

    def _find_call_target(self, call_name: str, nodes: Dict) -> str:
        """Find target node for a call"""
        if not isinstance(call_name, str):
            return None

        # Search for matching method/function
        for node_id, node_info in nodes.items():
            if (
                node_info["type"] in ["method", "function"]
                and node_info["name"] == call_name
            ):
                return node_id

        # Search for matching class
        for node_id, node_info in nodes.items():
            if node_info["type"] == "class" and node_info["name"] == call_name:
                return node_id

        return None

    def _determine_architecture_type(self) -> str:
        """Determine overall architecture type"""
        classes = self._safe_get_list("classes")
        functions = self._safe_get_list("functions")

        if not classes and functions:
            return "Procedural"
        elif len(classes) == 1:
            return "Single-Class"
        elif classes:
            return "Object-Oriented"
        else:
            return "Script"

    def _assess_complexity_level(self) -> str:
        """Assess code complexity level"""
        classes = self._safe_get_list("classes")
        total_methods = sum(
            len(self._safe_get_list_from_dict(cls, "methods")) for cls in classes
        )

        if not classes:
            return "Very Simple"
        elif total_methods < 5:
            return "Simple"
        elif total_methods < 15:
            return "Moderate"
        elif total_methods < 30:
            return "Complex"
        else:
            return "Very Complex"


# Utility function
def analyze_code(parsed_data: Dict[str, Any], save_json: bool = True) -> Dict[str, Any]:
    """Convenience function to analyze parsed code"""
    analyzer = CodeAnalyzer()
    analyzed_data = analyzer.analyze(parsed_data)

    if save_json:
        os.makedirs("assets/dot_sources", exist_ok=True)
        filename = parsed_data.get("filename", "unknown")
        json_filename = f"{os.path.splitext(filename)[0]}_analyzed.json"
        json_path = os.path.join("assets/dot_sources", json_filename)

        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(analyzed_data, f, indent=2, ensure_ascii=False)

        print(f"Analysis saved to: {json_path}")

    return analyzed_data
