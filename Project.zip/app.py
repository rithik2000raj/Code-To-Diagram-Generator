import streamlit as st
import os
import tempfile
import graphviz
import time
import re
from parser_module import parse_file
from analyzer import analyze_code
from diagram_generator import (
    generate_diagram,
    create_simple_diagram,
    create_error_diagram,
)
from llm_integration import (
    get_detailed_diagram_explanation,
    get_code_analysis_response,
    is_api_available,
)
from exporter import export_all_four_formats
from viewer import display_diagram_viewer
import theme_config as theme


# Load custom CSS
def load_css():
    """Load custom CSS styles"""
    try:
        with open("styles.css") as f:
            st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)
    except FileNotFoundError:
        st.warning("CSS file not found. Using default styles.")


# Page configuration
st.set_page_config(
    page_title="Code to Diagram Generator",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Load CSS and theme
load_css()


# Global timer for button state reset
def reset_button_states():
    """Reset all button states after a short delay"""
    current_time = time.time()
    if hasattr(st.session_state, "last_button_press_time"):
        if current_time - st.session_state.last_button_press_time > 0.5:
            # Reset all button states
            st.session_state.apply_changes_clicked = False
            st.session_state.reset_original_clicked = False


def initialize_session_state():
    """Initialize all session state variables"""
    session_vars = {
        "processed_data": None,
        "current_file": None,
        "graphviz_code": None,
        "diagram_path": None,
        "source_code_content": "",
        "query_page_chat_history": [],
        "last_api_call_time": 0,
        "edited_graphviz": "",
        "diagram_updated": False,
        "last_error": "",
        "exported_files": {},
        "apply_changes_clicked": False,
        "reset_original_clicked": False,
        "current_page": "Main Analysis",
        "diagram_explanation": "",
        "last_button_press_time": 0,
        "last_processed_question": None,
    }

    for var, default in session_vars.items():
        if var not in st.session_state:
            st.session_state[var] = default


def main():
    """Main application function"""
    initialize_session_state()
    reset_button_states()  # Reset button states on every run

    # Sidebar navigation
    st.sidebar.markdown(
        '<div class="sidebar-header">Navigation</div>', unsafe_allow_html=True
    )

    # Page selection
    page_options = ["Main Analysis", "Code Queries"]
    selected_page = st.sidebar.radio("", page_options, label_visibility="collapsed")

    # Update page state
    if selected_page != st.session_state.current_page:
        st.session_state.current_page = selected_page
        st.rerun()

    # Display page header
    display_page_header()

    # Route to appropriate page
    if st.session_state.current_page == "Main Analysis":
        main_analysis_page()
    else:
        code_queries_page()


def display_page_header():
    """Display modern page header with gradient"""
    st.markdown(
        """
        <div class="header-gradient">
            <h1 class="main-title">Code to Diagram Generator</h1>
            <p class="main-subtitle">Transform your code into interactive visual diagrams</p>
        </div>
        """,
        unsafe_allow_html=True,
    )


def main_analysis_page():
    """Main analysis page with file upload and diagram generation"""

    # File upload section
    uploaded_file = st.file_uploader(
        "Choose a code file",
        type=["py", "java", "ipynb"],
        help="Supported formats: Python (.py), Java (.java), Jupyter Notebook (.ipynb)",
        label_visibility="collapsed",
    )

    # Process uploaded file
    if uploaded_file and uploaded_file != st.session_state.current_file:
        process_uploaded_file(uploaded_file)

    # Display results if data is available
    if st.session_state.processed_data:
        display_analysis_results()
        display_diagram_section()
        display_diagram_explanation()
        display_export_section()


def code_queries_page():
    """Separate page for code queries with diagram and chat"""
    if not st.session_state.processed_data:
        st.warning(
            "Please upload and analyze a code file first from the Main Analysis page."
        )
        return

    # API status
    if not is_api_available():
        st.error("GROQ_API_KEY not found in .env file. AI features require API key.")

    # Single column layout for diagram only
    display_diagram_viewer_section()

    # Chat interface
    display_query_chat_interface()


def display_diagram_viewer_section():
    """Display diagram viewer section"""
    st.subheader("Current Diagram")

    # Get current graphviz code (use edited if available, otherwise original)
    current_graphviz = (
        st.session_state.edited_graphviz or st.session_state.graphviz_code
    )

    if st.session_state.diagram_path and current_graphviz:
        # Display diagram and editor
        col1, col2 = st.columns([1, 1])

        with col1:
            # Diagram display
            st.markdown("**Diagram Preview**")
            if os.path.exists(st.session_state.diagram_path):
                st.image(st.session_state.diagram_path, use_column_width=True)
            else:
                st.info("No diagram available")

        with col2:
            # Code editor
            st.markdown("**Graphviz Source Code**")
            edited_code = st.text_area(
                "Edit Graphviz code",
                value=current_graphviz,
                height=400,
                key="graphviz_editor",
                label_visibility="collapsed",
                placeholder="Edit your Graphviz DOT code here...",
            )

            # Update edited code when user makes changes
            if edited_code != st.session_state.edited_graphviz:
                st.session_state.edited_graphviz = edited_code

            # Editor actions
            col2a, col2b = st.columns(2)
            with col2a:
                if st.button(
                    "Apply Changes",
                    type="primary",
                    use_container_width=True,
                    key="apply_changes_main",
                ):
                    with st.spinner("Applying changes..."):
                        if regenerate_diagram_from_edited_code():
                            st.session_state.diagram_updated = True
                            st.session_state.last_button_press_time = time.time()
            with col2b:
                if st.button(
                    "Reset to Original",
                    use_container_width=True,
                    key="reset_original_main",
                ):
                    st.session_state.edited_graphviz = st.session_state.graphviz_code
                    with st.spinner("Resetting..."):
                        if regenerate_diagram_from_edited_code():
                            st.session_state.diagram_updated = True
                            st.session_state.last_button_press_time = time.time()
    else:
        st.info("Generate a diagram first from the Main Analysis page.")


def display_analysis_results():
    """Display code analysis insights"""
    data = st.session_state.processed_data

    st.subheader("Code Analysis Summary")

    # Key metrics in columns
    col1, col2, col3, col4 = st.columns(4)

    metrics_config = [
        ("Classes", len(data.get("classes", []))),
        ("Functions", len(data.get("functions", []))),
        (
            "Total Methods",
            sum(len(cls.get("methods", [])) for cls in data.get("classes", [])),
        ),
        ("Imports", len(data.get("imports", []))),
    ]

    for i, (label, value) in enumerate(metrics_config):
        with [col1, col2, col3, col4][i]:
            st.metric(label, value)

    # Architecture insights
    if "structure_summary" in data:
        summary = data["structure_summary"]
        arch_type = summary.get("architecture_type", "Unknown")
        complexity = summary.get("complexity_level", "Unknown")
        main_components = ", ".join(summary.get("main_components", ["None"]))

        st.info(
            f"""
        **Architecture Type:** {arch_type}  
        **Complexity Level:** {complexity}  
        **Main Components:** {main_components}
        """
        )


def display_diagram_section():
    """Display diagram generation section"""
    st.subheader("Code Diagram")

    # Diagram options
    use_simple = st.checkbox(
        "Use Simple Diagram",
        value=False,
        help="Use simplified visualization for complex files",
    )

    # Automatically generate and display diagram
    generate_and_display_diagram(use_simple)

    # Display current diagram if available
    display_current_diagram()


def generate_and_display_diagram(use_simple: bool):
    """Generate and display diagram based on complexity preference"""
    with st.spinner("Generating diagram..."):
        try:
            if use_simple:
                dot_code, diagram_path = create_simple_diagram(
                    st.session_state.processed_data
                )
            else:
                dot_code, diagram_path = generate_diagram(
                    st.session_state.processed_data
                )

            update_diagram_state(dot_code, diagram_path)

        except Exception as e:
            handle_diagram_error(e)


def update_diagram_state(dot_code: str, diagram_path: str):
    """Update session state with new diagram data"""
    st.session_state.graphviz_code = dot_code
    st.session_state.diagram_path = diagram_path
    if not st.session_state.edited_graphviz:
        st.session_state.edited_graphviz = dot_code

    # Clear previous explanation when generating new diagram
    st.session_state.diagram_explanation = ""


def handle_diagram_error(error: Exception):
    """Handle diagram generation errors"""
    st.error(f"Diagram generation error: {error}")
    dot_code, diagram_path = create_error_diagram(str(error))
    st.session_state.graphviz_code = dot_code
    st.session_state.diagram_path = diagram_path
    st.session_state.edited_graphviz = dot_code
    st.session_state.diagram_explanation = ""


def display_current_diagram():
    """Display the current diagram"""
    if st.session_state.diagram_path and os.path.exists(st.session_state.diagram_path):
        st.image(st.session_state.diagram_path, use_column_width=True)
        filename = st.session_state.processed_data.get("filename", "unknown")
        st.caption(f"Diagram generated from {filename}")
    else:
        st.info("Click 'Generate Diagram' to create a visualization")


def display_diagram_explanation():
    """Display AI-powered diagram explanation"""
    if not st.session_state.processed_data or not st.session_state.graphviz_code:
        return

    st.subheader("Diagram Explanation")

    # Generate explanation if not already generated
    if not st.session_state.diagram_explanation:
        with st.spinner("Generating detailed explanation..."):
            explanation = get_detailed_diagram_explanation(
                st.session_state.processed_data, st.session_state.graphviz_code
            )
            st.session_state.diagram_explanation = explanation

    # Display explanation
    if st.session_state.diagram_explanation:
        st.info(st.session_state.diagram_explanation)
    else:
        st.warning("Could not generate diagram explanation. Please try again.")


def display_export_section():
    """Export section for diagram formats"""
    if not st.session_state.processed_data or not st.session_state.graphviz_code:
        return

    st.subheader("Export Diagrams")

    # Export button
    if st.button(
        "Export All Formats (PNG, SVG, MD, DOT)",
        use_container_width=True,
        help="Export diagram in all available formats at once",
        type="primary",
    ):
        export_all_four_formats_handler()
        st.session_state.last_button_press_time = time.time()

    # Show exported files if any
    if st.session_state.exported_files:
        display_exported_files()


def export_all_four_formats_handler():
    """Handle export of all four formats"""
    if not st.session_state.graphviz_code:
        st.error("No diagram code available for export")
        return

    base_name = get_base_filename()

    try:
        with st.spinner("Exporting PNG, SVG, Markdown, and DOT files..."):
            exported_files = export_all_four_formats(
                st.session_state.graphviz_code, base_name
            )
            st.session_state.exported_files = exported_files
            display_export_results(exported_files)

    except Exception as e:
        st.error(f"Export failed: {str(e)}")


def get_base_filename():
    """Get base filename for exports"""
    if st.session_state.current_file:
        return os.path.splitext(st.session_state.current_file.name)[0]
    return "diagram"


def display_export_results(exported_files: dict):
    """Display export results"""
    if exported_files:
        success_msg = f"Successfully exported {len(exported_files)} file(s):"
        for fmt, path in exported_files.items():
            success_msg += f"\n• {fmt.upper()}: {os.path.basename(path)}"
        st.success(success_msg)
    else:
        st.warning("No files were exported")


def display_exported_files():
    """Display download buttons for exported files"""
    st.markdown("#### Download Exported Files")

    # Create columns for the formats
    cols = st.columns(4)

    format_configs = {
        "png": {"label": "PNG Image", "mime": "image/png"},
        "svg": {"label": "SVG Vector", "mime": "image/svg+xml"},
        "md": {"label": "Markdown", "mime": "text/markdown"},
        "dot": {"label": "DOT Source", "mime": "text/plain"},
    }

    for i, (format_name, file_path) in enumerate(
        st.session_state.exported_files.items()
    ):
        if os.path.exists(file_path):
            with cols[i % 4]:
                display_single_download_button(format_name, file_path, format_configs)


def display_single_download_button(
    format_name: str, file_path: str, format_configs: dict
):
    """Display download button for a single exported file"""
    try:
        with open(file_path, "rb") as file:
            file_data = file.read()

        config = format_configs.get(
            format_name,
            {"label": format_name.upper(), "mime": "application/octet-stream"},
        )

        base_name = get_base_filename()

        st.download_button(
            label=config["label"],
            data=file_data,
            file_name=f"{base_name}.{format_name}",
            mime=config["mime"],
            use_container_width=True,
            key=f"download_{format_name}",
        )

        # Show file size
        file_size = os.path.getsize(file_path) / 1024  # KB
        st.caption(f"{file_size:.1f} KB")

    except Exception as e:
        st.error(f"Error preparing {format_name} download: {str(e)}")


def display_query_chat_interface():
    """Display chat interface for code queries"""
    st.subheader("Ask About Your Code")

    # Display chat history
    display_chat_history()

    # Quick question suggestions
    display_quick_questions()

    # Manual question input
    display_question_input()


def display_chat_history():
    """Display chat history"""
    if st.session_state.query_page_chat_history:
        st.markdown("**Conversation History:**")
        for i, (message, is_user) in enumerate(
            st.session_state.query_page_chat_history
        ):
            message_class = "chat-user" if is_user else "chat-ai"
            st.markdown(
                f'<div class="chat-message {message_class}">{message}</div>',
                unsafe_allow_html=True,
            )


def display_quick_questions():
    """Display quick question suggestions"""
    st.markdown("**Quick Questions:**")
    suggestions = [
        "Explain the main classes and their responsibilities",
        "What's the overall architecture pattern?",
        "How do the components interact with each other?",
        "What improvements would you suggest for this code?",
        "Are there any potential design issues?",
        "Explain the key relationships in the diagram",
    ]

    cols = st.columns(3)
    for i, suggestion in enumerate(suggestions):
        col = cols[i % 3]
        with col:
            # Use a unique key for each button
            button_key = f"q_btn_{i}"

            # Check if button was clicked in this run
            if st.button(suggestion, key=button_key, use_container_width=True):
                # Use session state to track the last processed question
                if st.session_state.get("last_processed_question") != button_key:
                    st.session_state.last_processed_question = button_key
                    process_question(suggestion)
                    st.session_state.last_button_press_time = time.time()


def display_question_input():
    """Display manual question input"""
    st.markdown("**Or ask your own question:**")
    with st.form(key="question_form", clear_on_submit=True):
        user_question = st.text_area(
            "Your question:",
            placeholder="Ask anything about the code structure, architecture, or improvements...",
            height=80,
            label_visibility="collapsed",
        )
        submitted = st.form_submit_button("Ask Question", use_container_width=True)

        if submitted and user_question.strip():
            process_question(user_question.strip())
            st.session_state.last_button_press_time = time.time()


def process_question(question):
    """Process a single question"""
    current_time = time.time()

    # Rate limiting: 1 second between requests
    if current_time - st.session_state.last_api_call_time < 1:
        return

    st.session_state.last_api_call_time = current_time

    # Add user question to history
    st.session_state.query_page_chat_history.append((question, True))

    # Get AI response
    with st.spinner("Analyzing your code..."):
        ai_response = get_code_analysis_response(
            question,
            st.session_state.source_code_content,
            st.session_state.processed_data,
        )

        # Add AI response to history
        st.session_state.query_page_chat_history.append((ai_response, False))


def process_uploaded_file(uploaded_file):
    """Process the uploaded file through the entire pipeline"""
    file_ext = os.path.splitext(uploaded_file.name)[1].lower()

    with tempfile.NamedTemporaryFile(delete=False, suffix=file_ext) as tmp_file:
        tmp_file.write(uploaded_file.getvalue())
        temp_path = tmp_file.name

    try:
        # Read file content
        with open(temp_path, "r", encoding="utf-8") as f:
            st.session_state.source_code_content = f.read()

        # Parse and analyze code
        with st.spinner("Parsing code structure..."):
            parsed_data = parse_file(temp_path, save_json=True)

        with st.spinner("Analyzing code relationships..."):
            analyzed_data = analyze_code(parsed_data, save_json=True)

        # Update session state
        update_session_after_processing(analyzed_data, uploaded_file)

        st.success("Analysis complete!")

    except Exception as e:
        st.error(f"Error processing file: {str(e)}")
    finally:
        # Clean up temporary file
        if os.path.exists(temp_path):
            os.unlink(temp_path)


def update_session_after_processing(analyzed_data, uploaded_file):
    """Update session state after processing file"""
    st.session_state.processed_data = analyzed_data
    st.session_state.current_file = uploaded_file
    st.session_state.query_page_chat_history = []
    st.session_state.last_api_call_time = 0
    st.session_state.edited_graphviz = ""
    st.session_state.diagram_updated = False
    st.session_state.last_error = ""
    st.session_state.exported_files = {}
    st.session_state.diagram_explanation = ""
    st.session_state.last_button_press_time = time.time()
    st.session_state.last_processed_question = None


def regenerate_diagram_from_edited_code():
    """Regenerate diagram from edited Graphviz code"""
    if not st.session_state.edited_graphviz:
        return False

    try:
        base_name = os.path.splitext(st.session_state.processed_data["filename"])[0]
        diagram_path = f"assets/diagrams/{base_name}_edited"

        dot = graphviz.Source(st.session_state.edited_graphviz)
        dot.render(diagram_path, format="png", cleanup=True)

        st.session_state.diagram_path = diagram_path + ".png"
        st.session_state.diagram_updated = True
        st.session_state.last_error = ""
        st.session_state.diagram_explanation = ""
        return True

    except graphviz.ExecutableNotFound:
        st.session_state.last_error = (
            "Graphviz executable not found. Please install Graphviz."
        )
        return False
    except graphviz.backend.CalledProcessError as e:
        error_msg = str(e)
        if "stderr: b'" in error_msg:
            match = re.search(r"stderr: b'([^']*)'", error_msg)
            if match:
                clean_error = (
                    match.group(1).replace("\\r\\n", "\n").replace("\\n", "\n")
                )
                st.session_state.last_error = f"Graphviz syntax error:\n{clean_error}"
            else:
                st.session_state.last_error = "Graphviz processing error"
        else:
            st.session_state.last_error = f"Graphviz error: {error_msg}"
        return False
    except Exception as e:
        st.session_state.last_error = f"Unexpected error: {str(e)}"
        return False


# Run the application
if __name__ == "__main__":
    main()
