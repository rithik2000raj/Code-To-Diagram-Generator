// test.java
// Complex example for Code-to-Diagram Generator testing
// Demonstrates interfaces, inheritance, control flow, and method calls.

import java.util.*;

interface Notifier {
    void send(String recipient, String message);
}

class EmailNotifier implements Notifier {
    @Override
    public void send(String recipient, String message) {
        System.out.println("[Email] Sending to " + recipient + ": " + message);
    }
}

class SMSNotifier implements Notifier {
    @Override
    public void send(String recipient, String message) {
        System.out.println("[SMS] Sending to " + recipient + ": " + message);
    }
}

abstract class UserRepository {
    protected List<String> users = new ArrayList<>();

    public abstract void save(String username);

    public boolean exists(String username) {
        return users.contains(username);
    }
}

class InMemoryUserRepository extends UserRepository {
    @Override
    public void save(String username) {
        users.add(username);
        System.out.println("Saved user in memory: " + username);
    }
}

class RegistrationService {
    private final UserRepository repo;
    private final Notifier notifier;

    public RegistrationService(UserRepository repo, Notifier notifier) {
        this.repo = repo;
        this.notifier = notifier;
    }

    public void register(String username, String contact) {
        System.out.println("Attempting registration for: " + username);

        if (repo.exists(username)) {
            System.out.println("User already exists: " + username);
            return;
        }

        repo.save(username);
        notifier.send(contact, "Welcome, " + username + "!");
    }

    public void bulkRegister(List<String> users, String contactDomain) {
        for (String user : users) {
            String contact = user.toLowerCase() + contactDomain;
            register(user, contact);
        }
    }
}

class AdminService extends RegistrationService {
    public AdminService(UserRepository repo, Notifier notifier) {
        super(repo, notifier);
    }

    public void deactivateUser(String username) {
        System.out.println("Deactivating user: " + username);
        // Simulate complex logic
        if (username.startsWith("A")) {
            System.out.println("High priority deactivation for admin: " + username);
        }
    }
}

public class MainApp {
    public static void main(String[] args) {
        UserRepository repo = new InMemoryUserRepository();
        Notifier email = new EmailNotifier();
        Notifier sms = new SMSNotifier();

        RegistrationService regService = new RegistrationService(repo, email);
        AdminService adminService = new AdminService(repo, sms);

        List<String> newUsers = Arrays.asList("Alice", "Bob", "Charlie");
        regService.bulkRegister(newUsers, "@example.com");

        adminService.deactivateUser("Alice");
    }
}
