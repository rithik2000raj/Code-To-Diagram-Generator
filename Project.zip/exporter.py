import os
import graphviz
from typing import Dict, Optional
import re


class DiagramExporter:
    """
    Simplified exporter for PNG, SVG, MD, and DOT formats only.
    Provides clean, focused functionality for the four required formats.
    """

    def __init__(self, output_dir: str = "assets/diagrams"):
        self.output_dir = output_dir
        self._ensure_output_directory()

    def _ensure_output_directory(self):
        """Create output directory if it doesn't exist"""
        os.makedirs(self.output_dir, exist_ok=True)

    def export_all_formats(self, dot_source: str, base_filename: str) -> Dict[str, str]:
        """
        Export diagram to all four formats: PNG, SVG, MD, DOT

        Args:
            dot_source: Graphviz DOT source code
            base_filename: Base name for output files

        Returns:
            Dictionary mapping format -> filepath for successful exports
        """
        if not dot_source or not base_filename:
            raise ValueError("dot_source and base_filename are required")

        # Clean base filename
        safe_filename = self._sanitize_filename(base_filename)
        export_results = {}

        try:
            # Export PNG
            png_path = self.export_png(dot_source, safe_filename)
            if png_path:
                export_results["png"] = png_path

            # Export SVG
            svg_path = self.export_svg(dot_source, safe_filename)
            if svg_path:
                export_results["svg"] = svg_path

            # Export DOT
            dot_path = self.export_dot(dot_source, safe_filename)
            if dot_path:
                export_results["dot"] = dot_path

            # Export Markdown (requires PNG to be exported first)
            if png_path:
                md_path = self.export_markdown(dot_source, safe_filename, png_path)
                if md_path:
                    export_results["md"] = md_path

            return export_results

        except graphviz.ExecutableNotFound:
            raise RuntimeError(
                "Graphviz executable not found. Please install Graphviz from https://graphviz.org/download/"
            )
        except Exception as e:
            raise RuntimeError(f"Export failed: {str(e)}")

    def export_png(self, dot_source: str, base_filename: str) -> Optional[str]:
        """
        Export diagram to PNG format

        Returns:
            Path to PNG file or None if failed
        """
        return self._render_image_format(dot_source, base_filename, "png")

    def export_svg(self, dot_source: str, base_filename: str) -> Optional[str]:
        """
        Export diagram to SVG format

        Returns:
            Path to SVG file or None if failed
        """
        return self._render_image_format(dot_source, base_filename, "svg")

    def export_dot(self, dot_source: str, base_filename: str) -> Optional[str]:
        """
        Export Graphviz source to DOT file

        Returns:
            Path to DOT file
        """
        try:
            dot_filename = f"{base_filename}.dot"
            dot_path = os.path.join(self.output_dir, dot_filename)

            with open(dot_path, "w", encoding="utf-8") as f:
                f.write(dot_source)

            return dot_path
        except Exception as e:
            print(f"❌ DOT export failed: {str(e)}")
            return None

    def export_markdown(
        self, dot_source: str, base_filename: str, png_path: str
    ) -> Optional[str]:
        """
        Export diagram and source to Markdown documentation

        Returns:
            Path to Markdown file
        """
        try:
            md_filename = f"{base_filename}.md"
            md_path = os.path.join(self.output_dir, md_filename)

            # Get PNG filename for relative reference
            png_filename = os.path.basename(png_path)

            markdown_content = self._generate_markdown_content(
                base_filename, png_filename, dot_source
            )

            with open(md_path, "w", encoding="utf-8") as f:
                f.write(markdown_content)

            return md_path
        except Exception as e:
            print(f"❌ Markdown export failed: {str(e)}")
            return None

    def _render_image_format(
        self, dot_source: str, base_filename: str, format: str
    ) -> Optional[str]:
        """
        Render diagram to image format (PNG/SVG)
        """
        try:
            graph = graphviz.Source(dot_source)
            output_path = os.path.join(self.output_dir, base_filename)

            rendered_path = graph.render(
                filename=output_path, format=format, cleanup=True
            )

            if rendered_path and os.path.exists(rendered_path):
                return rendered_path

        except graphviz.backend.CalledProcessError as e:
            error_msg = self._parse_graphviz_error(str(e))
            print(f"❌ {format.upper()} export failed: {error_msg}")
        except Exception as e:
            print(f"❌ {format.upper()} export failed: {str(e)}")

        return None

    def _generate_markdown_content(
        self, base_name: str, png_filename: str, dot_source: str
    ) -> str:
        """
        Generate clean markdown documentation
        """
        content = [
            f"# Code Diagram: {base_name}",
            "",
            "## Diagram",
            f"![{base_name} Diagram]({png_filename})",
            "",
            "## Graphviz Source Code",
            "```dot",
            dot_source,
            "```",
            "",
            "---",
            f"*Generated by Code-to-Diagram Generator*",
            "",
        ]

        return "\n".join(content)

    def _sanitize_filename(self, filename: str) -> str:
        """Sanitize filename to be filesystem-safe"""
        # Remove invalid characters and replace with underscores
        sanitized = re.sub(r'[<>:"/\\|?*]', "_", filename)
        # Limit length and remove trailing spaces
        return sanitized.strip()[:100]

    def _parse_graphviz_error(self, error_msg: str) -> str:
        """Extract meaningful error message from Graphviz output"""
        patterns = [
            r"Error:\s*(.*?)(?=\n|$)",
            r"stderr:\s*b?'([^']*)'",
            r"syntax error.*?line\s+\d+",
        ]

        for pattern in patterns:
            match = re.search(pattern, error_msg, re.IGNORECASE)
            if match:
                clean_error = match.group(1) if match.lastindex else match.group(0)
                clean_error = clean_error.replace("\\n", "\n").replace("\\r", "")
                return clean_error.strip()

        return f"Graphviz error: {error_msg[:100]}..."


# Simplified utility functions
def export_png(dot_source: str, base_filename: str) -> str:
    """Export to PNG format only"""
    exporter = DiagramExporter()
    return exporter.export_png(dot_source, base_filename) or ""


def export_svg(dot_source: str, base_filename: str) -> str:
    """Export to SVG format only"""
    exporter = DiagramExporter()
    return exporter.export_svg(dot_source, base_filename) or ""


def export_dot(dot_source: str, base_filename: str) -> str:
    """Export to DOT format only"""
    exporter = DiagramExporter()
    return exporter.export_dot(dot_source, base_filename) or ""


def export_markdown(dot_source: str, base_filename: str, png_path: str) -> str:
    """Export to Markdown format only"""
    exporter = DiagramExporter()
    return exporter.export_markdown(dot_source, base_filename, png_path) or ""


def export_all_four_formats(dot_source: str, base_filename: str) -> Dict[str, str]:
    """Export to all four formats in one call"""
    exporter = DiagramExporter()
    return exporter.export_all_formats(dot_source, base_filename)
