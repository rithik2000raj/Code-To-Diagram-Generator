import os
import json
import ast
import javalang
import nbformat
from typing import Dict, List, Any, Union
import tempfile


class MultiLanguageParser:
    """Parser for Python, Java, and Jupyter Notebook files"""

    def __init__(self):
        self.supported_extensions = {".py", ".java", ".ipynb"}

    def parse_file(self, file_path: str) -> Dict[str, Any]:
        """Main entry point - parse file based on extension"""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")

        file_ext = os.path.splitext(file_path)[1].lower()

        if file_ext == ".py":
            return self._parse_python(file_path)
        elif file_ext == ".java":
            return self._parse_java(file_path)
        elif file_ext == ".ipynb":
            return self._parse_jupyter(file_path)
        else:
            raise ValueError(
                f"Unsupported file type: {file_ext}. Supported: {self.supported_extensions}"
            )

    def _parse_python(self, file_path: str) -> Dict[str, Any]:
        """Parse Python files using AST"""
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                code_content = f.read()

            tree = ast.parse(code_content)

            parsed_data = {
                "filename": os.path.basename(file_path),
                "language": "python",
                "classes": [],
                "functions": [],
                "imports": [],
                "global_variables": [],
                "structure": [],
            }

            # Extract imports
            for node in tree.body:
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        parsed_data["imports"].append(
                            {"name": alias.name, "alias": alias.asname}
                        )
                elif isinstance(node, ast.ImportFrom):
                    module = node.module or ""
                    for alias in node.names:
                        parsed_data["imports"].append(
                            {
                                "name": f"{module}.{alias.name}",
                                "alias": alias.asname,
                                "module": module,
                            }
                        )

            # Extract classes and functions
            for node in tree.body:
                if isinstance(node, ast.ClassDef):
                    class_info = {
                        "name": node.name,
                        "line_start": node.lineno,
                        "methods": [],
                        "attributes": self._extract_class_attributes(node),
                        "bases": [self._get_base_name(base) for base in node.bases],
                    }

                    # Extract methods
                    for item in node.body:
                        if isinstance(item, ast.FunctionDef):
                            method_info = {
                                "name": item.name,
                                "calls": self._extract_function_calls(item),
                                "line_start": item.lineno,
                                "parameters": [
                                    arg.arg
                                    for arg in item.args.args
                                    if arg.arg != "self"
                                ],
                            }
                            class_info["methods"].append(method_info)

                    parsed_data["classes"].append(class_info)
                    parsed_data["structure"].append(
                        {"type": "class", "name": node.name, "line": node.lineno}
                    )

                elif isinstance(node, ast.FunctionDef):
                    # Only top-level functions (not methods)
                    func_info = {
                        "name": node.name,
                        "line_start": node.lineno,
                        "calls": self._extract_function_calls(node),
                        "parameters": [arg.arg for arg in node.args.args],
                    }
                    parsed_data["functions"].append(func_info)
                    parsed_data["structure"].append(
                        {"type": "function", "name": node.name, "line": node.lineno}
                    )

                elif isinstance(node, ast.Assign):
                    # Global variables
                    for target in node.targets:
                        if isinstance(target, ast.Name):
                            parsed_data["global_variables"].append(target.id)

            return parsed_data

        except SyntaxError as e:
            raise SyntaxError(f"Python syntax error in {file_path}: {e}")
        except Exception as e:
            raise Exception(f"Error parsing Python file {file_path}: {e}")

    def _parse_java(self, file_path: str) -> Dict[str, Any]:
        """Parse Java files using javalang"""
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                code_content = f.read()

            tree = javalang.parse.parse(code_content)

            parsed_data = {
                "filename": os.path.basename(file_path),
                "language": "java",
                "classes": [],
                "methods": [],
                "imports": [],
                "structure": [],
            }

            # Extract imports
            for import_decl in tree.imports:
                parsed_data["imports"].append(
                    {
                        "path": import_decl.path,
                        "static": (
                            import_decl.static
                            if hasattr(import_decl, "static")
                            else False
                        ),
                    }
                )

            # Extract classes and methods
            for path, node in tree.filter(javalang.tree.ClassDeclaration):
                class_info = {
                    "name": node.name,
                    "methods": [],
                    "fields": [],
                    "extends": str(node.extends.name) if node.extends else None,
                    "implements": (
                        [str(impl.name) for impl in node.implements]
                        if node.implements
                        else []
                    ),
                }

                # Extract methods
                for member in node.body:
                    if isinstance(member, javalang.tree.MethodDeclaration):
                        method_info = {
                            "name": member.name,
                            "return_type": (
                                str(member.return_type)
                                if member.return_type
                                else "void"
                            ),
                            "parameters": [
                                self._serialize_java_parameter(param)
                                for param in member.parameters
                            ],
                            "modifiers": (
                                list(member.modifiers) if member.modifiers else []
                            ),  # Convert set to list
                        }
                        class_info["methods"].append(method_info)
                        parsed_data["structure"].append(
                            {"type": "method", "class": node.name, "name": member.name}
                        )

                    elif isinstance(member, javalang.tree.FieldDeclaration):
                        for declarator in member.declarators:
                            field_info = {
                                "name": declarator.name,
                                "type": str(member.type),
                                "modifiers": (
                                    list(member.modifiers) if member.modifiers else []
                                ),  # Convert set to list
                            }
                            class_info["fields"].append(field_info)

                parsed_data["classes"].append(class_info)
                parsed_data["structure"].append({"type": "class", "name": node.name})

            return parsed_data

        except javalang.parser.JavaSyntaxError as e:
            raise SyntaxError(f"Java syntax error in {file_path}: {e}")
        except Exception as e:
            raise Exception(f"Error parsing Java file {file_path}: {e}")

    def _parse_jupyter(self, file_path: str) -> Dict[str, Any]:
        """Parse Jupyter Notebook files - extract code from all cells"""
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                notebook = nbformat.read(f, as_version=4)

            # Combine all code cells into one Python file content
            all_code = ""
            code_cells = []

            for i, cell in enumerate(notebook.cells):
                if cell.cell_type == "code":
                    code_content = cell.source
                    all_code += f"# Cell {i+1}\n{code_content}\n\n"
                    code_cells.append(
                        {
                            "cell_number": i + 1,
                            "code": code_content,
                            "outputs": len(cell.get("outputs", [])),
                        }
                    )

            if not all_code.strip():
                return {
                    "filename": os.path.basename(file_path),
                    "language": "jupyter",
                    "classes": [],
                    "functions": [],
                    "imports": [],
                    "global_variables": [],
                    "structure": [],
                    "code_cells": code_cells,
                    "note": "No code cells found in notebook",
                }

            # Create temporary Python file with combined code
            with tempfile.NamedTemporaryFile(
                mode="w", suffix=".py", delete=False, encoding="utf-8"
            ) as temp_file:
                temp_file.write(all_code)
                temp_path = temp_file.name

            try:
                # Parse the combined code as Python
                parsed_data = self._parse_python(temp_path)
                parsed_data["filename"] = os.path.basename(file_path)
                parsed_data["language"] = "jupyter"
                parsed_data["code_cells"] = code_cells

                return parsed_data
            except SyntaxError:
                # If syntax error, return basic structure
                return {
                    "filename": os.path.basename(file_path),
                    "language": "jupyter",
                    "classes": [],
                    "functions": [],
                    "imports": [],
                    "global_variables": [],
                    "structure": [],
                    "code_cells": code_cells,
                    "note": "Code cells contain syntax errors or non-Python code",
                }
            finally:
                # Clean up temporary file
                if os.path.exists(temp_path):
                    os.unlink(temp_path)

        except Exception as e:
            raise Exception(f"Error parsing Jupyter notebook {file_path}: {e}")

    def _extract_class_attributes(self, class_node: ast.ClassDef) -> List[str]:
        """Extract class attributes/variables"""
        attributes = []
        for node in class_node.body:
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        attributes.append(target.id)
        return attributes

    def _extract_function_calls(self, function_node: ast.FunctionDef) -> List[str]:
        """Extract function calls from a function"""
        calls = []
        for node in ast.walk(function_node):
            if isinstance(node, ast.Call):
                if isinstance(node.func, ast.Name):
                    calls.append(node.func.id)
                elif isinstance(node.func, ast.Attribute):
                    calls.append(node.func.attr)
        return list(set(calls))  # Remove duplicates

    def _get_base_name(self, base_node: ast.AST) -> str:
        """Get the name of a base class"""
        if isinstance(base_node, ast.Name):
            return base_node.id
        elif isinstance(base_node, ast.Attribute):
            return base_node.attr
        else:
            return str(base_node)

    def _serialize_java_parameter(self, param) -> Dict[str, str]:
        """Serialize Java parameter to JSON-serializable dict"""
        return {"type": str(param.type) if param.type else "", "name": param.name}

    def save_parsed_json(
        self, parsed_data: Dict[str, Any], output_dir: str = "assets/dot_sources"
    ):
        """Save parsed data as JSON for later use"""
        os.makedirs(output_dir, exist_ok=True)

        filename = parsed_data["filename"]
        json_filename = f"{os.path.splitext(filename)[0]}_parsed.json"
        json_path = os.path.join(output_dir, json_filename)

        # Ensure all data is JSON serializable
        serializable_data = self._make_json_serializable(parsed_data)

        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(serializable_data, f, indent=2, ensure_ascii=False)

        return json_path

    def _make_json_serializable(self, data: Any) -> Any:
        """Recursively convert data to JSON-serializable types"""
        if isinstance(data, (str, int, float, bool, type(None))):
            return data
        elif isinstance(data, (list, tuple)):
            return [self._make_json_serializable(item) for item in data]
        elif isinstance(data, dict):
            return {
                str(key): self._make_json_serializable(value)
                for key, value in data.items()
            }
        elif isinstance(data, set):
            return [self._make_json_serializable(item) for item in data]
        else:
            return str(data)


# Utility function for easy usage
def parse_file(file_path: str, save_json: bool = True) -> Dict[str, Any]:
    """Convenience function to parse any supported file type"""
    parser = MultiLanguageParser()
    parsed_data = parser.parse_file(file_path)

    if save_json:
        json_path = parser.save_parsed_json(parsed_data)
        print(f"Parsed data saved to: {json_path}")

    return parsed_data
